

import java.io.IOException;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import org.eclipse.jetty.server.Server;
import org.eclipse.jetty.websocket.api.Session;
import org.eclipse.jetty.websocket.api.annotations.OnWebSocketClose;
import org.eclipse.jetty.websocket.api.annotations.OnWebSocketConnect;
import org.eclipse.jetty.websocket.api.annotations.OnWebSocketError;
import org.eclipse.jetty.websocket.api.annotations.OnWebSocketMessage;
import org.eclipse.jetty.websocket.api.annotations.WebSocket;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;


@WebSocket
public class NetworkPlayer{
	private Session session;
	private int idClient = -1;
	
    @OnWebSocketClose
    public void onClose(int statusCode, String reason) {
    	System.err.println("Client disconnected");
    }

    @OnWebSocketError
    public void onError(Throwable t) {
        System.out.println("Error NetworkClient: " + t.getMessage());
    }

    @OnWebSocketConnect
    public void onConnect(Session session) {
    	System.err.println("Client connected !");
    	this.session = session;
    	System.err.println("Client connected !");
    }

    @OnWebSocketMessage
    public void onMessage(String message) {
    	System.out.println("Message recu d'un client: " + message);
    	JSONParser parser = new JSONParser();
    	JSONObject json = null;
    	try {json = (JSONObject) parser.parse(message);} catch (Exception e) {}
    
    	if(json != null && json.get("cmd") != null && json.get("cmd").equals("areas"))
    		sendAreasTest();
    }

	private void sendAreasTest() {
		this.send("{ \"areas\": [ { \"name\": \"Quartier Nord\", \"map\": { \"weight\": {\"w\": 1, \"h\": 1}, \"vertices\": [ {\"name\": \"m\", \"x\": 0.5, \"y\": 0.5}, {\"name\": \"b\", \"x\": 0.5, \"y\": 1} ], \"streets\": [ {\"name\": \"mb\", \"path\": [\"m\", \"b\"], \"oneway\": false} ], \"bridges\": [ { \"from\": \"b\", \"to\": { \"area\": \"Quartier Sud\", \"vertex\": \"h\"}, \"weight\": 2 } ] } }, { \"name\": \"Quartier Sud\", \"map\": { \"weight\": {\"w\": 1, \"h\": 1}, \"vertices\": [ {\"name\": \"a\", \"x\": 1, \"y\": 1}, {\"name\": \"m\", \"x\": 0, \"y\": 1}, {\"name\": \"h\", \"x\": 0.5, \"y\": 0} ], \"streets\": [ {\"name\": \"ah\", \"path\": [\"a\", \"h\"], \"oneway\": false}, {\"name\": \"mh\", \"path\": [\"m\", \"h\"], \"oneway\": false} ], \"bridges\": [ { \"from\": \"h\", \"to\": { \"area\": \"Quartier Nord\", \"vertex\": \"b\"}, \"weight\": 2 } ] } } ] }");
	}
	
    public void send(String message) {
    	if(this.session.isOpen())
    		try {session.getRemote().sendString(message);} catch (IOException e1) {}
    	System.out.println("Sended message");
    }
    

    
}