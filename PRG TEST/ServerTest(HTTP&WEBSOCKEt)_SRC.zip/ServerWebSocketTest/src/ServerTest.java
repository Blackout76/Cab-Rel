
import java.util.ArrayList;
import java.util.HashMap;

import org.omg.CORBA.TIMEOUT;

/**
 * <h2>
 * @author Blackout
 * </h2>
 */
public class ServerTest {
	public final static String SERVER_VERSION = "0.0.1";
	public final static String LOCAL_IP = "192.168.1.10";
	public final static int SERVER_PORT = 2009;
	public final static int SERVER_HTTP_PORT = 80;
	

	private static NetworkServer serverListening = new NetworkServer(SERVER_PORT);
	protected static boolean shutDown = false;

	
	public static void main(String[] args){
		init();
		run();
		quit();
		
	}

	public static void quit() {
		cleanup();
		System.exit(0);
	}
	
	private static void cleanup() {
		serverListening.stop();
	}

	private static void run() {
		while(!shutDown){
			
		}
		cleanup();
		System.out.println("Server is shuting down !");
		
	}

	private static void init() {
		System.out.println("Server start in version : " + SERVER_VERSION);
        org.eclipse.jetty.server.Server server = new org.eclipse.jetty.server.Server(80);
        server.setHandler(new HelloWorld());
        try {
			server.start();
	        server.join();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("Server is ready !");
		System.out.println("---------------------------------------");
	}
	
	
}
