



import java.net.InetSocketAddress;
import java.util.Map;

import org.eclipse.jetty.server.Server;
import org.eclipse.jetty.websocket.server.WebSocketHandler;
import org.eclipse.jetty.websocket.servlet.WebSocketServletFactory;

/**
 * <h2>
 * This class listen on Websocket in a new thread and create new NetworkPlayer when a client is connected
 * @author Blackout
 * </h2>
 */

public class NetworkServer{
	private ThreadListening listening;

	/**
	 * @param port The port of the server listening. Example: 2009
	 */
	public NetworkServer(int port){
		this.listening = new ThreadListening(port);
		new Thread(this.listening).start();
	}

	/**
	 * @param stop Clean and stop the ThreadListening
	 */
	public void stop() {
		listening.cleanup();
	}
	
	

	/**
	 * <h2>
	 * Class ThreadListening is the Thread running for get new clients.
	 * @author Blackout
	 * </h2>
	 */
	private class ThreadListening implements Runnable{
		private int port = 66000;

		/**
		 * @param port The port of the server listening. Example: 2009
		 */
		public ThreadListening (int port){
			this.port = port;
		}

		/**
		 * Start the Thread with methode init()
		 * @see init()
		 */
		public void run() {
			try {init();} catch (Exception e) {e.printStackTrace();}
		}

		public void init() throws Exception {
			Server server = new Server(this.port);
		    WebSocketHandler wsHandler = new WebSocketHandler() {
		        @Override
		        public void configure(WebSocketServletFactory factory) {
		            factory.register(NetworkPlayer.class);
		        }
		    };
		    server.setHandler(wsHandler);
		    server.start();
		    server.join();
		}

		public void cleanup() {
			
		}
	}



}
